import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from scipy.signal import savgol_filter
from sklearn.metrics import mean_absolute_error, r2_score
import os, time

# 检查是否有GPU可用
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

# Attention block
class AttentionBlock(nn.Module):
    def __init__(self, input_dim):
        super(AttentionBlock, self).__init__()
        self.attention_weights = nn.Linear(input_dim, input_dim)
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x):
        attention = self.softmax(self.attention_weights(x))
        return attention * x

# CNN-Attention 模型
class CNNAttentionModel(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(CNNAttentionModel, self).__init__()

        # Conv1D 层 (相当于 Keras 中的 Conv1D)
        self.conv1d = nn.Conv1d(in_channels=input_dim, out_channels=128, kernel_size=1)

        # Attention 层
        self.attention = AttentionBlock(128)  # 这里的128是卷积后输出的通道数

        # 全连接层 (输出层)
        self.fc = nn.Linear(128, output_dim)

    def forward(self, x):
        # CNN 部分
        x = x.permute(0, 2, 1)  # 交换维度以匹配 Conv1d 输入 (batch_size, channels, sequence_length)
        x = self.conv1d(x)
        x = x.permute(0, 2, 1)  # 交换回去 (batch_size, sequence_length, channels)

        # Attention 部分
        attn_out = self.attention(x)

        # 输出层
        output = self.fc(attn_out[:, -1, :])  # 取最后一个时间步的输出
        return output


# 多维归一化函数
def NormalizeMult(data):
    normalize = np.zeros((data.shape[1], 2), dtype='float64')
    for i in range(data.shape[1]):
        list_col = data[:, i]
        list_low, list_high = np.percentile(list_col, [0, 100])
        normalize[i, 0] = list_low
        normalize[i, 1] = list_high
        delta = list_high - list_low
        if delta != 0:
            data[:, i] = (data[:, i] - list_low) / delta
    return data, normalize


# 反归一化函数
def DenormalizeMult(data, normalize):
    for i in range(data.shape[1]):
        data[:, i] = data[:, i] * (normalize[i, 1] - normalize[i, 0]) + normalize[i, 0]
    return data


# 使用Savitzky-Golay滤波器对数据进行平滑处理
def smooth_data(data, window_length=101, polyorder=3):
    if len(data) >= window_length:
        smoothed_data = savgol_filter(data, window_length=window_length, polyorder=polyorder)
        # 确保不产生负值
        smoothed_data = np.where(smoothed_data < 0, 0, smoothed_data)
        return smoothed_data
    else:
        return data


# 数据处理
data = pd.read_csv("./Data_acceleration.csv")
input_data = data.iloc[:, [1, 4]].values
target_data = data.iloc[:, 3].values.reshape(-1, 1)

input_data, normalize_input = NormalizeMult(input_data)
target_data, normalize_target = NormalizeMult(target_data)

# 设置超参数
TIME_STEPS = 100
INPUT_DIMS = 2
OUTPUT_DIMS = 1
BATCH_SIZE = 128
LEARNING_RATE = 0.001
EPOCHS = 200
MODEL_PATH = "CNN-AM_brake.pth"
PATIENCE = 20  # 设置提前停止的容忍度

# 创建数据集
def create_dataset(data, look_back):
    dataX, dataY = [], []
    for i in range(len(data) - look_back - 1):
        a = data[i:(i + look_back), :]
        dataX.append(a)
        dataY.append(data[i + look_back, :])
    return np.array(dataX), np.array(dataY)


train_X, _ = create_dataset(input_data, TIME_STEPS)
_, train_Y = create_dataset(target_data, TIME_STEPS)
train_X, val_X, train_Y, val_Y = train_test_split(train_X, train_Y, test_size=0.4, random_state=42)

# 转换为PyTorch的Tensor并创建数据加载器
train_dataset = TensorDataset(torch.tensor(train_X, dtype=torch.float32), torch.tensor(train_Y, dtype=torch.float32))
val_dataset = TensorDataset(torch.tensor(val_X, dtype=torch.float32), torch.tensor(val_Y, dtype=torch.float32))

train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)

# 实例化模型并设置优化器和损失函数
model = CNNAttentionModel(INPUT_DIMS, OUTPUT_DIMS).to(device)
optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)
loss_fn = nn.HuberLoss(delta=0.018)

if os.path.exists(MODEL_PATH):
    model.load_state_dict(torch.load(MODEL_PATH))
    print("已加载保存的模型")
else:
    print("未找到已保存的模型，从头开始训练...")

# 训练和验证损失记录
history = {
    'train_loss': [],
    'val_loss': []
}

# 训练模型并记录损失
def train_model(model, train_loader, val_loader, epochs, patience):
    best_val_loss = float('inf')
    patience_counter = 0
    for epoch in range(epochs):
        start_time = time.time()
        model.train()
        running_train_loss = 0.0
        for i, (batch_X, batch_Y) in enumerate(train_loader):
            batch_X, batch_Y = batch_X.to(device), batch_Y.to(device)

            outputs = model(batch_X)

            # 修正的损失计算逻辑
            loss = loss_fn(outputs, batch_Y)  # 预测值和真实值计算损失
            running_train_loss += loss.item()

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        # 记录训练损失
        train_loss = running_train_loss / len(train_loader)
        history['train_loss'].append(train_loss)

        # 验证
        model.eval()
        running_val_loss = 0.0
        all_predictions = []
        all_actuals = []
        with torch.no_grad():
            for batch_X, batch_Y in val_loader:
                batch_X, batch_Y = batch_X.to(device), batch_Y.to(device)

                outputs = model(batch_X)

                # 验证时也同样修正损失计算逻辑
                val_loss = loss_fn(outputs, batch_Y)
                running_val_loss += val_loss.item()
                # 收集预测和真实值
                all_predictions.append(outputs.cpu().numpy())
                all_actuals.append(batch_Y.cpu().numpy())

        val_loss = running_val_loss / len(val_loader)
        history['val_loss'].append(val_loss)
        # 计算 R² 和 MAE
        all_predictions = np.concatenate(all_predictions, axis=0)
        all_actuals = np.concatenate(all_actuals, axis=0)
        mae = mean_absolute_error(all_actuals, all_predictions)
        r2 = r2_score(all_actuals, all_predictions)
        epoch_time = time.time() - start_time
        print(f"Epoch {epoch + 1}/{epochs}, Training Loss: {train_loss}, Validation Loss: {val_loss}, MAE: {mae}, R²: {r2}, Time: {epoch_time:.2f}s")
        # 检查是否出现过拟合
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            # 保存最佳模型
            torch.save(model.state_dict(), MODEL_PATH)
        else:
            patience_counter += 1
            if patience_counter >= patience:
                print("验证集损失在连续 {} 轮中没有改善，提前停止训练".format(patience))
                break

# 调用训练函数
train_model(model, train_loader, val_loader, EPOCHS, PATIENCE)

# 绘制损失曲线
def plot_loss(history):
    train_loss_smoothed = smooth_data(np.array(history['train_loss']), window_length=11, polyorder=3)
    val_loss_smoothed = smooth_data(np.array(history['val_loss']), window_length=11, polyorder=3)
    plt.plot(train_loss_smoothed, label='Train Loss')
    plt.plot(val_loss_smoothed, label='Validation Loss')
    plt.title('Model Loss')
    plt.ylabel('Loss')
    plt.xlabel('Epoch')
    plt.legend()
    plt.show()


# 调用绘图函数
plot_loss(history)

# 在验证集上进行预测并绘制对比图
def visualize_predictions(model, val_loader):
    model.eval()
    predictions = []
    actuals = []
    with torch.no_grad():
        for batch_X, batch_Y in val_loader:
            batch_X, batch_Y = batch_X.to(device), batch_Y.to(device)

            outputs = model(batch_X)
            predictions.append(outputs.cpu().numpy())
            actuals.append(batch_Y.cpu().numpy())

    predictions = np.concatenate(predictions, axis=0)
    actuals = np.concatenate(actuals, axis=0)
    # 反归一化预测值和真实值
    predictions = DenormalizeMult(predictions, normalize_target)
    actuals = DenormalizeMult(actuals, normalize_target)

    # 平滑数据
    predictions_smoothed = smooth_data(predictions.flatten())
    actuals_smoothed = smooth_data(actuals.flatten())
    mae = np.mean(np.abs(predictions - actuals))
    print(f"反归一化后的平均绝对误差（MAE）: {mae}")
    # 绘制对比图
    plt.figure(figsize=(10, 6))
    sample_rate = 50  # Change this value to adjust how sparse the plot is
    sampled_indices = np.arange(0, len(actuals), sample_rate)
    plt.plot(sampled_indices, actuals[sampled_indices], label="Actual Data (Sampled)", color='orange', alpha=0.6)
    plt.plot(sampled_indices, predictions[sampled_indices], label="Predicted Data (Sampled)", color='blue', linestyle='--', alpha=0.6)

    # 平滑曲线（不采样）
    plt.plot(actuals_smoothed, 'r-', label="Smoothed Actual Data", linewidth=2, antialiased=True)
    plt.plot(predictions_smoothed, 'b-', label="Smoothed Predicted Data", linewidth=2, antialiased=True)

    plt.title("Validation Data: Actual vs Predicted")
    plt.xlabel("Samples")
    plt.ylabel("Value")
    plt.legend()
    plt.show()

# 调用可视化预测和真实值的函数
visualize_predictions(model, val_loader)
