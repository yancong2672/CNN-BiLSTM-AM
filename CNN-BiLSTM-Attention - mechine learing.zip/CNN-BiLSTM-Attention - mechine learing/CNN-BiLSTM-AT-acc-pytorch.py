import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from scipy.signal import savgol_filter
from sklearn.metrics import mean_absolute_error, r2_score
import os,time

# 检查是否有GPU可用
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

# Attention block
class AttentionBlock(nn.Module):
    def __init__(self, input_dim):
        super(AttentionBlock, self).__init__()
        # 增强的多头注意力（4头->8头）
        self.time_attn = nn.MultiheadAttention(
            embed_dim=input_dim,
            num_heads=8,  # 增加注意力头数
            batch_first=True
        )
        # 通道注意力（结构不变）
        self.channel_attn = nn.Sequential(
            nn.Linear(input_dim, input_dim // 4),
            nn.ReLU(),
            nn.Linear(input_dim // 4, input_dim),
            nn.Sigmoid()
        )
        # 新增层归一化
        self.norm = nn.LayerNorm(input_dim)
        self.alpha = nn.Parameter(torch.tensor(0.6))

    def forward(self, x):
        # 带残差连接的时间注意力
        time_out, _ = self.time_attn(x, x, x)
        time_out = self.norm(time_out + x)  # 残差连接

        # 通道注意力（逻辑不变）
        channel_weights = self.channel_attn(x.mean(dim=1))
        channel_out = x * channel_weights.unsqueeze(1)

        # 动态融合
        return self.alpha * time_out + (1 - self.alpha) * channel_out


# 修改后的模型（保持类名和变量名）
class CNNBiLSTMAttentionModel(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers, output_dim, cnn_kernel_size, dropout):
        super(CNNBiLSTMAttentionModel, self).__init__()

        # 修改的卷积层（保持conv1d变量名）
        self.conv1d = nn.Sequential(
            nn.Conv1d(in_channels=input_dim, out_channels=128, kernel_size=cnn_kernel_size, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2)  # 新增池化层
        )

        # BiLSTM（参数名不变，新增dropout）
        self.lstm = nn.LSTM(
            input_size=128,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if num_layers > 1 else 0
        )

        # 注意力层（保持变量名）
        self.attention = AttentionBlock(hidden_dim * 2)

        # 增强的全连接层（保持fc变量名）
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, 64),
            nn.ReLU(),
            nn.Linear(64, output_dim)
        )

    def forward(self, x, h_0, c_0):
        # 修改后的CNN流程
        x = x.permute(0, 2, 1)  # [B, D, T]
        x = self.conv1d(x)  # [B, 128, T//2]
        x = x.permute(0, 2, 1)  # [B, T//2, 128]

        # LSTM（参数不变）
        lstm_out, (h_n, c_n) = self.lstm(x, (h_0, c_0))

        # 注意力（调用不变）
        attn_out = self.attention(lstm_out)

        # 输出层（保持逻辑）
        return self.fc(attn_out[:, -1, :])


# 多维归一化函数
def NormalizeMult(data):
    normalize = np.zeros((data.shape[1], 2), dtype='float64')
    for i in range(data.shape[1]):
        list_col = data[:, i]
        list_low, list_high = np.percentile(list_col, [0, 100])
        normalize[i, 0] = list_low
        normalize[i, 1] = list_high
        delta = list_high - list_low
        if delta != 0:
            data[:, i] = (data[:, i] - list_low) / delta
    return data, normalize


# 反归一化函数
def DenormalizeMult(data, normalize):
    for i in range(data.shape[1]):
        data[:, i] = data[:, i] * (normalize[i, 1] - normalize[i, 0]) + normalize[i, 0]
    return data


# 使用Savitzky-Golay滤波器对数据进行平滑处理
def smooth_data(data, window_length=101, polyorder=3):
    if len(data) >= window_length:
        smoothed_data = savgol_filter(data, window_length=window_length, polyorder=polyorder)
        # 确保不产生负值
        smoothed_data = np.where(smoothed_data < 0, 0, smoothed_data)
        return smoothed_data
    else:
        return data

# 创建数据集
def create_dataset(data, look_back):
    dataX, dataY = [], []
    for i in range(len(data) - look_back - 1):
        a = data[i:(i + look_back), :]
        dataX.append(a)
        dataY.append(data[i + look_back, :])
    return np.array(dataX), np.array(dataY)


# 训练模型并记录损失
def train_model(model, train_loader, val_loader, epochs,patience):
    best_val_loss = float('inf')
    patience_counter = 0
    for epoch in range(epochs):
        start_time = time.time()
        model.train()
        running_train_loss = 0.0
        for i, (batch_X, batch_Y) in enumerate(train_loader):
            batch_X, batch_Y = batch_X.to(device), batch_Y.to(device)

            h_0 = torch.zeros(NUM_LAYERS * 2, batch_X.size(0), HIDDEN_DIMS).to(device)
            c_0 = torch.zeros(NUM_LAYERS * 2, batch_X.size(0), HIDDEN_DIMS).to(device)

            outputs = model(batch_X, h_0, c_0)

            # 修正的损失计算逻辑
            loss = loss_fn(outputs, batch_Y)  # 预测值和真实值计算损失
            running_train_loss += loss.item()

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        # 记录训练损失
        train_loss = running_train_loss / len(train_loader)
        history['train_loss'].append(train_loss)

        # 验证
        model.eval()
        running_val_loss = 0.0
        all_predictions = []
        all_actuals = []
        with torch.no_grad():
            for batch_X, batch_Y in val_loader:
                batch_X, batch_Y = batch_X.to(device), batch_Y.to(device)
                h_0 = torch.zeros(NUM_LAYERS * 2, batch_X.size(0), HIDDEN_DIMS).to(device)
                c_0 = torch.zeros(NUM_LAYERS * 2, batch_X.size(0), HIDDEN_DIMS).to(device)

                outputs = model(batch_X, h_0, c_0)

                # 验证时也同样修正损失计算逻辑
                val_loss = loss_fn(outputs, batch_Y)
                running_val_loss += val_loss.item()
                # 收集预测和真实值
                all_predictions.append(outputs.cpu().numpy())
                all_actuals.append(batch_Y.cpu().numpy())

        val_loss = running_val_loss / len(val_loader)
        history['val_loss'].append(val_loss)
        # 计算 R² 和 MAE
        all_predictions = np.concatenate(all_predictions, axis=0)
        all_actuals = np.concatenate(all_actuals, axis=0)
        mae = mean_absolute_error(all_actuals, all_predictions)
        r2 = r2_score(all_actuals, all_predictions)
        epoch_time = time.time() - start_time
        print(f"Epoch {epoch + 1}/{epochs}, Training Loss: {train_loss}, Validation Loss: {val_loss}, MAE: {mae}, R²: {r2}, Time: {epoch_time:.2f}s")
        # 检查是否出现过拟合
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            # 保存最佳模型
            torch.save(model.state_dict(), MODEL_PATH)
        else:
            patience_counter += 1
            if patience_counter >= patience:
                print("验证集损失在连续 {} 轮中没有改善，提前停止训练".format(patience))
                break

# 调用训练函数


# 绘制损失曲线
def plot_loss(history):
    train_loss_smoothed = smooth_data(np.array(history['train_loss']), window_length=11, polyorder=3)
    val_loss_smoothed = smooth_data(np.array(history['val_loss']), window_length=11, polyorder=3)
    plt.plot(train_loss_smoothed, label='Train Loss')
    plt.plot(val_loss_smoothed, label='Validation Loss')
    plt.title('Model Loss')
    plt.ylabel('Loss')
    plt.xlabel('Epoch')
    plt.legend()
    plt.show()


# 调用绘图函数

# 在验证集上进行预测并绘制对比图
def visualize_predictions(model, val_loader):
    model.eval()
    predictions = []
    actuals = []
    with torch.no_grad():
        for batch_X, batch_Y in val_loader:
            batch_X, batch_Y = batch_X.to(device), batch_Y.to(device)
            h_0 = torch.zeros(NUM_LAYERS * 2, batch_X.size(0), HIDDEN_DIMS).to(device)
            c_0 = torch.zeros(NUM_LAYERS * 2, batch_X.size(0), HIDDEN_DIMS).to(device)
            outputs = model(batch_X, h_0, c_0)
            predictions.append(outputs.cpu().numpy())
            actuals.append(batch_Y.cpu().numpy())

    predictions = np.concatenate(predictions, axis=0)
    actuals = np.concatenate(actuals, axis=0)
    # 反归一化预测值和真实值
    predictions = DenormalizeMult(predictions, normalize_target)
    actuals = DenormalizeMult(actuals, normalize_target)

    # 平滑数据
    predictions_smoothed = smooth_data(predictions.flatten())
    actuals_smoothed = smooth_data(actuals.flatten())
    mae = np.mean(np.abs(predictions - actuals))
    print(f"反归一化后的平均绝对误差（MAE）: {mae}")
    # 绘制对比图
    plt.figure(figsize=(10, 6))
    sample_rate = 50  # Change this value to adjust how sparse the plot is
    sampled_indices = np.arange(0, len(actuals), sample_rate)
    plt.plot(sampled_indices, actuals[sampled_indices], label="Actual Data (Sampled)", color='orange', alpha=0.6)
    plt.plot(sampled_indices, predictions[sampled_indices], label="Predicted Data (Sampled)", color='blue', linestyle='--', alpha=0.6)

    # 平滑曲线（不采样）
    plt.plot(actuals_smoothed, 'r-', label="Smoothed Actual Data", linewidth=2, antialiased=True)
    plt.plot(predictions_smoothed, 'b-', label="Smoothed Predicted Data", linewidth=2, antialiased=True)

    plt.title("Validation Data: Actual vs Predicted")
    plt.xlabel("Samples")
    plt.ylabel("Value")
    plt.legend()
    plt.show()

# 调用可视化预测和真实值的函数
#visualize_predictions(model, val_loader)
def visualize_new_data_predictions(model, new_data_path):
    """加载新数据验证模型的独立函数"""
    # 加载新数据（保持与原始数据相同的列）
    new_data = pd.read_csv(new_data_path)
    new_inputs = new_data.iloc[:, [1, 4]].values
    new_targets = new_data.iloc[:, 2].values.reshape(-1, 1)

    # 使用训练数据的归一化参数（关键！）
    # 输入数据归一化
    for i in range(new_inputs.shape[1]):
        min_val = normalize_input[i, 0]
        max_val = normalize_input[i, 1]
        delta = max_val - min_val
        new_inputs[:, i] = (new_inputs[:, i] - min_val) / (delta + 1e-8)

    # 目标数据归一化
    new_targets = (new_targets - normalize_target[0, 0]) / (normalize_target[0, 1] - normalize_target[0, 0] + 1e-8)

    # 创建新数据集（复用原有函数）
    new_X, _ = create_dataset(new_inputs, TIME_STEPS)
    _, new_Y = create_dataset(new_targets, TIME_STEPS)

    # 创建新数据加载器（保持参数一致）
    new_dataset = TensorDataset(
        torch.tensor(new_X, dtype=torch.float32),
        torch.tensor(new_Y, dtype=torch.float32)
    )
    new_loader = DataLoader(new_dataset, batch_size=BATCH_SIZE, shuffle=False)

    # 执行可视化（复用原有函数）
    print(f"\n正在验证新数据: {new_data_path}")
    visualize_predictions(model, new_loader)

if __name__ == "__main__":
    # 数据处理
    data = pd.read_csv("./Data_acceleration.csv")
    input_data = data.iloc[:, [1, 4]].values
    target_data = data.iloc[:, 3].values.reshape(-1, 1)
    train_input = input_data[6000:]
    train_target = target_data[6000:]
    val_input = input_data[:6000]
    val_target = target_data[:6000]
    input_data_nor, normalize_input = NormalizeMult(train_input)
    target_data_nor, normalize_target = NormalizeMult(train_target)
    val_input_normalized = (val_input - normalize_input[:, 0]) / (normalize_input[:, 1] - normalize_input[:, 0] + 1e-8)
    val_target_normalized = (val_target - normalize_target[:, 0]) / (
                normalize_target[:, 1] - normalize_target[:, 0] + 1e-8)

    # 设置超参数
    TIME_STEPS = 100
    INPUT_DIMS = 2
    HIDDEN_DIMS = 128
    NUM_LAYERS = 2
    OUTPUT_DIMS = 1
    BATCH_SIZE = 128
    LEARNING_RATE = 0.001
    EPOCHS = 200
    MODEL_PATH = "best_model_brk.pth"
    PATIENCE = 20  # 设置提前停止的容忍度

    train_X, _ = create_dataset(input_data_nor, TIME_STEPS)
    _, train_Y = create_dataset(target_data_nor, TIME_STEPS)
    train_X, val_input, train_Y, val_target = train_test_split(train_X, train_Y, test_size=0.1, random_state=42)
    val_X, _ = create_dataset(val_input_normalized, TIME_STEPS)
    _, val_Y = create_dataset(val_target_normalized, TIME_STEPS)
    # 转换为PyTorch的Tensor并创建数据加载器
    train_dataset = TensorDataset(torch.tensor(train_X, dtype=torch.float32),
                                  torch.tensor(train_Y, dtype=torch.float32))
    train_val_dataset = TensorDataset(torch.tensor(val_input, dtype=torch.float32),
                                      torch.tensor(val_target, dtype=torch.float32))
    val_dataset = TensorDataset(torch.tensor(val_X, dtype=torch.float32), torch.tensor(val_Y, dtype=torch.float32))
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
    train_val_loader = DataLoader(train_val_dataset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)
    # 实例化模型并设置优化器和损失函数
    model = CNNBiLSTMAttentionModel(INPUT_DIMS, HIDDEN_DIMS, NUM_LAYERS, OUTPUT_DIMS,cnn_kernel_size=7,dropout=0.4).to(device)
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)
    loss_fn = nn.HuberLoss(delta=0.018)

    if os.path.exists(MODEL_PATH):
        model.load_state_dict(torch.load(MODEL_PATH))
        print("已加载保存的模型")
    else:
        print("未找到已保存的模型，从头开始训练...")

    # 训练和验证损失记录
    history = {
        'train_loss': [],
        'val_loss': []
    }
    train_model(model, train_loader, train_val_loader, EPOCHS, PATIENCE)
    plot_loss(history)
    visualize_predictions(model, val_loader)
    #visualize_new_data_predictions(model, "./yz.csv")