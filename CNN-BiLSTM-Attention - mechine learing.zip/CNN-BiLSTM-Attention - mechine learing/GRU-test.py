import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from scipy.signal import savgol_filter
import os
from sklearn.metrics import mean_absolute_error, r2_score
# 检查是否有GPU可用
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

# Attention block
class GRUModel(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers, output_dim):
        super(GRUModel, self).__init__()

        # GRU 层 (Gated Recurrent Unit)
        self.gru = nn.GRU(input_size=input_dim, hidden_size=hidden_dim, num_layers=num_layers, batch_first=True)

        # 全连接层 (输出层)
        self.fc = nn.Linear(hidden_dim, output_dim)

    def forward(self, x, h_0):
        # GRU 部分
        gru_out, h_n = self.gru(x, h_0)

        # 输出层
        output = self.fc(gru_out[:, -1, :])  # 取最后一个时间步的输出
        return output

# 多维归一化函数
def NormalizeMult(data):
    normalize = np.zeros((data.shape[1], 2), dtype='float64')
    for i in range(data.shape[1]):
        list_col = data[:, i]
        list_low, list_high = np.percentile(list_col, [0, 100])
        normalize[i, 0] = list_low
        normalize[i, 1] = list_high
        delta = list_high - list_low
        if delta != 0:
            data[:, i] = (data[:, i] - list_low) / delta
    return data, normalize


# 反归一化函数
def DenormalizeMult(data, normalize):
    for i in range(data.shape[1]):
        data[:, i] = data[:, i] * (normalize[i, 1] - normalize[i, 0]) + normalize[i, 0]
    return data


# 使用Savitzky-Golay滤波器对数据进行平滑处理
def smooth_data(data, window_length=101, polyorder=3):
    if len(data) >= window_length:
        smoothed_data = savgol_filter(data, window_length=window_length, polyorder=polyorder)
        # 确保不产生负值
        smoothed_data = np.where(smoothed_data < 0, 0, smoothed_data)
        return smoothed_data
    else:
        return data


# 数据处理
data = pd.read_csv("./Data_acceleration.csv")
input_data = data.iloc[:, [1, 4]].values
target_data = data.iloc[:, 2].values.reshape(-1, 1)

input_data, normalize_input = NormalizeMult(input_data)
target_data, normalize_target = NormalizeMult(target_data)

# 设置超参数
TIME_STEPS = 100
INPUT_DIMS = 2
HIDDEN_DIMS = 128
NUM_LAYERS = 2
OUTPUT_DIMS = 1
BATCH_SIZE = 128
MODEL_PATH = "best_model_gru.pth"

# 创建数据集
def create_dataset(data, look_back):
    dataX, dataY = [], []
    for i in range(len(data) - look_back - 1):
        a = data[i:(i + look_back), :]
        dataX.append(a)
        dataY.append(data[i + look_back, :])
    return np.array(dataX), np.array(dataY)


train_X, _ = create_dataset(input_data, TIME_STEPS)
_, train_Y = create_dataset(target_data, TIME_STEPS)

# 转换为PyTorch的Tensor并创建数据加载器
val_dataset = TensorDataset(torch.tensor(train_X, dtype=torch.float32), torch.tensor(train_Y, dtype=torch.float32))
val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)

# 实例化模型并设置优化器和损失函数
model = GRUModel(INPUT_DIMS, HIDDEN_DIMS, NUM_LAYERS, OUTPUT_DIMS).to(device)

if os.path.exists(MODEL_PATH):
    model.load_state_dict(torch.load(MODEL_PATH))
    print("已加载保存的模型")
else:
    print("未找到已保存的模型，从头开始训练...")

# 训练和验证损失记录
history = {
    'train_loss': [],
    'val_loss': []
}
def record_predictions_to_excel(model, val_loader, file_path="GRU-acc-predictions_real.xlsx"):
    model.eval()
    predictions = []
    actuals = []
    errors = []
    with torch.no_grad():
        for batch_X, batch_Y in val_loader:
            batch_X, batch_Y = batch_X.to(device), batch_Y.to(device)
            h_0 = torch.zeros(NUM_LAYERS, batch_X.size(0), HIDDEN_DIMS).to(device)
            outputs = model(batch_X, h_0)
            predictions.append(outputs.cpu().numpy())
            actuals.append(batch_Y.cpu().numpy())

    predictions = np.concatenate(predictions, axis=0)
    actuals = np.concatenate(actuals, axis=0)

    # 反归一化
    predictions = DenormalizeMult(predictions, normalize_target)
    actuals = DenormalizeMult(actuals, normalize_target)
    r_2 = r2_score(actuals.flatten(), predictions.flatten())
    print(f"决定系数 (R²): {r_2}")
    # 平滑数据
    predictions_smoothed = smooth_data(predictions.flatten())
    actuals_smoothed = smooth_data(actuals.flatten())
    # 计算误差
    errors = predictions_smoothed.flatten() - actuals_smoothed.flatten()
    mae = mean_absolute_error(actuals_smoothed.flatten(), predictions_smoothed.flatten())
    r2 = r2_score(actuals_smoothed.flatten(), predictions_smoothed.flatten())
    print(f"平均绝对误差 (MAE): {mae}")
    print(f"决定系数 (R²): {r2}")
    # 保存到Excel文件
    df = pd.DataFrame({
        "Predicted": predictions_smoothed.flatten(),
        "Actual": actuals_smoothed.flatten(),
        "Error": errors
    })
    df.to_excel(file_path, index=False)
    print(f"预测结果已保存到 {file_path}")


# 调用函数保存结果到Excel
record_predictions_to_excel(model, val_loader)

# 在验证集上进行预测并绘制对比图
def visualize_predictions(model, val_loader):
    model.eval()
    predictions = []
    actuals = []
    with torch.no_grad():
        for batch_X, batch_Y in val_loader:
            batch_X, batch_Y = batch_X.to(device), batch_Y.to(device)
            h_0 = torch.zeros(NUM_LAYERS, batch_X.size(0), HIDDEN_DIMS).to(device)
            outputs = model(batch_X, h_0)
            predictions.append(outputs.cpu().numpy())
            actuals.append(batch_Y.cpu().numpy())

    predictions = np.concatenate(predictions, axis=0)
    actuals = np.concatenate(actuals, axis=0)
    # 反归一化预测值和真实值
    predictions = DenormalizeMult(predictions, normalize_target)
    actuals = DenormalizeMult(actuals, normalize_target)

    # 平滑数据
    predictions_smoothed = smooth_data(predictions.flatten())
    actuals_smoothed = smooth_data(actuals.flatten())
    mae = np.mean(np.abs(predictions - actuals))
    print(f"反归一化后的平均绝对误差（MAE）: {mae}")
    # 绘制对比图
    plt.figure(figsize=(10, 6))
    sample_rate = 50  # Change this value to adjust how sparse the plot is
    sampled_indices = np.arange(0, len(actuals), sample_rate)
    plt.plot(sampled_indices, actuals[sampled_indices], label="Actual Data (Sampled)", color='orange', alpha=0.6)
    plt.plot(sampled_indices, predictions[sampled_indices], label="Predicted Data (Sampled)", color='blue', linestyle='--', alpha=0.6)

    # 平滑曲线（不采样）
    plt.plot(actuals_smoothed, 'r-', label="Smoothed Actual Data", linewidth=2, antialiased=True)
    plt.plot(predictions_smoothed, 'b-', label="Smoothed Predicted Data", linewidth=2, antialiased=True)

    plt.title("Validation Data: Actual vs Predicted")
    plt.xlabel("Samples")
    plt.ylabel("Value")
    plt.legend()
    plt.show()

# 调用可视化预测和真实值的函数
visualize_predictions(model, val_loader)
