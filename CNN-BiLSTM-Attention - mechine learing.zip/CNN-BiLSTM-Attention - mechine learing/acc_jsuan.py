import pandas as pd
import numpy as np
import sys, os

def cur_file_dir():
    path = sys.path[0]
    if os.path.isdir(path):
        return path
    elif os.path.isfile(path):
        return os.path.dirname(path)
def get_mydata_with_acceleration(filename):
    # 读取CSV文件
    try:
        data = pd.read_csv(os.path.join(cur_file_dir(), "data", filename))
    except UnicodeDecodeError:
        data = pd.read_csv(os.path.join(cur_file_dir(), "data", filename),encoding='gbk')
    data = np.transpose(np.array(data)).astype(np.float32)

    # 提取时间、速度、油门和刹车
    time_data = data[0, :]  # 时间（第一列）
    speed_data = data[1, :]  # 速度（第二列）
    throttle_data = data[2, :]  # 油门（第三列）
    brake_data = data[3, :]  # 刹车（第四列）

    # 初始化加速度数组
    acceleration_data = np.zeros_like(speed_data)

    # 计算加速度
    time_diff = time_data[1] - time_data[0]  # 时间差假设是固定的
    for i in range(len(speed_data)):
        if i < len(speed_data) - 1:
            # 当前速度与下一速度的差除以时间差
            acceleration_data[i] = (speed_data[i + 1] - speed_data[i]) / time_diff
        else:
            # 最后一组数据，下一速度视为0
            acceleration_data[i] = -speed_data[i] / time_diff

    # 组合数据为 [时间, 速度, 油门, 刹车, 加速度]
    combined_data = np.vstack((time_data, speed_data, throttle_data, brake_data, acceleration_data)).T

    return combined_data


def save_data_with_acceleration(filename, output_filename):
    # 获取带加速度的数据
    combined_data = get_mydata_with_acceleration(filename)

    # 将数据保存到新的CSV文件
    output_df = pd.DataFrame(combined_data, columns=['时间', '速度', '油门', '刹车', '加速度'])
    output_df.to_csv(os.path.join(cur_file_dir(), "data", output_filename), index=False)
    print(f"数据已保存到 {output_filename}")


if __name__ == '__main__':
    # 文件名
    filename = "xlj-utf-8.csv"
    output_filename = "Data_acceleration.csv"

    # 保存计算后的数据
    save_data_with_acceleration(filename, output_filename)
