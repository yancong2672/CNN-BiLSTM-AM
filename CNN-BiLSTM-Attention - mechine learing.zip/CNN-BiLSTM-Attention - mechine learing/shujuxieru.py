import pandas as pd
import chardet
# Step 1: 检测文件编码
file_path = 'Data_xl.csv'
with open(file_path, 'rb') as f:
    result = chardet.detect(f.read())
    real_encoding = result['encoding']
    print(f"检测到的编码: {real_encoding} (置信度: {result['confidence']:.2f})")
# Step 2: 按真实编码读取文件
try:
    data = pd.read_csv(file_path, encoding=real_encoding)
except UnicodeDecodeError:
    # 如果检测有误，尝试常见中文编码
    data = pd.read_csv(file_path, encoding='GB18030')  # 兼容性更好的中文编码

# Save the modified CSV with UTF-8 encoding
output_path = 'xl.csv'
data.to_csv(output_path, index=False, encoding='utf-8')

print(f"Modified file saved at: {output_path}")